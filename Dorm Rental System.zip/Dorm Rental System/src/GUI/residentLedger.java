/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JInternalFrame.java to edit this template
 */
package GUI;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import javax.swing.JOptionPane;
import javax.swing.plaf.basic.BasicInternalFrameUI;
import net.proteanit.sql.DbUtils;

/**
 *
 * @author ASUS ROG STRIX
 */
public class residentLedger extends javax.swing.JInternalFrame {

    /**
     * Creates new form dormManagement
     */
    public residentLedger() {
        initComponents();
        this.setBorder(javax.swing.BorderFactory.createEmptyBorder(0,0,0,0));
        BasicInternalFrameUI ui=(BasicInternalFrameUI)this.getUI();
        ui.setNorthPane(null);
    dormTable();
    }Connection Con = null;
    Statement St = null;
     ResultSet Rs= null;
public void dormTable(){
    try{
        
        Con= DriverManager.getConnection("jdbc:mysql://localhost:3307/drs","root","");
        St = Con.createStatement();
        Rs = St.executeQuery("SELECT residentmanagement.Student_ID as 'ID',\n" +
                                "       residentmanagement.Name as 'Full Name',\n" +
                                "       residentmanagement.Age,\n" +
                                "       residentmanagement.Sex,\n" +
                                "       residentmanagement.Birthdate,\n" +
                                "       residentmanagement.Civil_Status as 'Civil Status',\n" +
                                "       residentmanagement.Phone_Number as 'Phone Number',\n" +
                                "       boardingfee.d_No as 'Dorm Number',\n" +
                                "       boardingfee.Dorm_Type as 'Dorm Type',\n" +
                                "       boardingfee.Rental_Rates as 'Rental Rates',\n" +
                                "       boardingfee.payment_status as 'Rent Payment Status',\n" +
                                "       boardingnob.transactiondate as 'Rent Date of Payment',\n" +
                                "       studentelectricbill.ElectricBill_Number as 'Electric Bill Number',\n" +
                                "       studentelectricbill.Meter_Reading as 'Electric Bill Meter Reading',\n" +
                                "       studentelectricbill.Subtotal as 'Electric Bill Subtotal',\n" +
                                "       studentelectricbill.Penalty as 'Electric Bill Penalty',\n" +
                                "       studentelectricbill.Electric_Bill_Total as 'Electric Bill Total',\n" +
                                "       studentelectricbill.billingdate as 'Electric Billing Date',\n" +
                                "       studentelectricbill.Due_Date as 'Electric Bill Due Date',\n" +
                                "       studentelectricbill.PaymentStatus as 'Electric Bill Status',\n" +
                                "       electricnob.transactiondate as 'Electric Bill Transaction Date',\n" +
                                "       studentwaterbill.WaterBill_Number as 'Water Bill Number',\n" +
                                "       studentwaterbill.Meter_Reading as 'Water Bill Meter Reading',\n" +
                                "       studentwaterbill.Subtotal as 'Water Bill Subtotal',\n" +
                                "       studentwaterbill.Penalty as 'Water Bill Penalty',\n" +
                                "       studentwaterbill.Water_Bill_Total as 'Water Bill Total',\n" +
                                "       studentwaterbill.billingdate as 'Water Billing Date',\n" +
                                "       studentwaterbill.Due_Date as 'Water Bill Due Date',\n" +
                                "       studentwaterbill.PaymentStatus as 'Water Bill Status',\n" +
                                "       waternob.transactiondate as 'Water Bill Transaction Date'\n" +
                                "FROM residentmanagement\n" +
                                "LEFT JOIN boardingfee ON residentmanagement.Student_ID = boardingfee.s_ID\n" +
                                "LEFT JOIN studentwaterbill ON studentwaterbill.Student_ID = residentmanagement.Student_ID\n" +
                                "LEFT JOIN studentelectricbill ON studentelectricbill.Student_ID = residentmanagement.Student_ID\n" +
                                "LEFT JOIN boardingnob ON boardingnob.studentid = residentmanagement.Student_ID\n" +
                                "LEFT JOIN electricnob ON residentmanagement.Student_ID = electricnob.studentid\n" +
                                "LEFT JOIN waternob ON residentmanagement.Student_ID = waternob.studentid");
        jTable1.setModel(DbUtils.resultSetToTableModel(Rs));
        
    }catch(SQLException e){
        e.printStackTrace();
        
    }}

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        panel1 = new java.awt.Panel();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();
        surnamesearch = new javax.swing.JTextField();
        jLabel1 = new javax.swing.JLabel();
        dp = new javax.swing.JCheckBox();
        pd = new javax.swing.JCheckBox();
        panel2 = new java.awt.Panel();
        jLabel7 = new javax.swing.JLabel();

        panel1.setBackground(new java.awt.Color(30, 43, 51));

        jTable1.setBackground(new java.awt.Color(51, 51, 51));
        jTable1.setForeground(new java.awt.Color(255, 255, 255));
        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        jTable1.setAutoResizeMode(javax.swing.JTable.AUTO_RESIZE_OFF);
        jScrollPane1.setViewportView(jTable1);

        surnamesearch.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                surnamesearchMouseClicked(evt);
            }
        });
        surnamesearch.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                surnamesearchActionPerformed(evt);
            }
        });
        surnamesearch.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                surnamesearchKeyPressed(evt);
            }
            public void keyReleased(java.awt.event.KeyEvent evt) {
                surnamesearchKeyReleased(evt);
            }
            public void keyTyped(java.awt.event.KeyEvent evt) {
                surnamesearchKeyTyped(evt);
            }
        });

        jLabel1.setForeground(new java.awt.Color(255, 255, 255));
        jLabel1.setText("Search");

        dp.setForeground(new java.awt.Color(255, 255, 255));
        dp.setText("Delayed Payment");
        dp.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                dpActionPerformed(evt);
            }
        });

        pd.setForeground(new java.awt.Color(255, 255, 255));
        pd.setText("Paid");
        pd.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                pdActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout panel1Layout = new javax.swing.GroupLayout(panel1);
        panel1.setLayout(panel1Layout);
        panel1Layout.setHorizontalGroup(
            panel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panel1Layout.createSequentialGroup()
                .addGap(17, 17, 17)
                .addGroup(panel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addGroup(panel1Layout.createSequentialGroup()
                        .addComponent(jLabel1)
                        .addGap(18, 18, 18)
                        .addComponent(surnamesearch, javax.swing.GroupLayout.PREFERRED_SIZE, 293, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(dp)
                        .addGap(83, 83, 83)
                        .addComponent(pd))
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 944, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(29, Short.MAX_VALUE))
        );
        panel1Layout.setVerticalGroup(
            panel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panel1Layout.createSequentialGroup()
                .addGap(17, 17, 17)
                .addGroup(panel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(surnamesearch, javax.swing.GroupLayout.PREFERRED_SIZE, 34, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel1)
                    .addComponent(dp)
                    .addComponent(pd))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 417, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(155, Short.MAX_VALUE))
        );

        panel2.setBackground(new java.awt.Color(3, 135, 140));

        jLabel7.setFont(new java.awt.Font("sansserif", 0, 48)); // NOI18N
        jLabel7.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel7.setText("RESIDENT LEDGER");

        javax.swing.GroupLayout panel2Layout = new javax.swing.GroupLayout(panel2);
        panel2.setLayout(panel2Layout);
        panel2Layout.setHorizontalGroup(
            panel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jLabel7, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        panel2Layout.setVerticalGroup(
            panel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panel2Layout.createSequentialGroup()
                .addGap(19, 19, 19)
                .addComponent(jLabel7, javax.swing.GroupLayout.PREFERRED_SIZE, 57, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(24, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(panel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(panel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addComponent(panel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, 0)
                .addComponent(panel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void surnamesearchMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_surnamesearchMouseClicked
        //surnamesearch.setText("");
    }//GEN-LAST:event_surnamesearchMouseClicked

    private void surnamesearchKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_surnamesearchKeyPressed

        try{
            String url = "jdbc:mysql://localhost:3307/drs";
            Connection conn = DriverManager.getConnection(url,"root","");
            Statement st = conn.createStatement();
            String query = "SELECT residentmanagement.Student_ID as 'ID',\n" +
"       residentmanagement.Name as 'Full Name',\n" +
"       residentmanagement.Age,\n" +
"       residentmanagement.Sex,\n" +
"       residentmanagement.Birthdate,\n" +
"       residentmanagement.Civil_Status as 'Civil Status',\n" +
"       residentmanagement.Phone_Number as 'Phone Number',\n" +
"       boardingfee.d_No as 'Dorm Number',\n" +
"       boardingfee.Dorm_Type as 'Dorm Type',\n" +
"       boardingfee.Rental_Rates as 'Rental Rates',\n" +
"       boardingfee.payment_status as 'Rent Payment Status',\n" +
"       boardingnob.transactiondate as 'Rent Date of Payment',\n" +
"       studentelectricbill.ElectricBill_Number as 'Electric Bill Number',\n" +
"       studentelectricbill.Meter_Reading as 'Electric Bill Meter Reading',\n" +
"       studentelectricbill.Subtotal as 'Electric Bill Subtotal',\n" +
"       studentelectricbill.Penalty as 'Electric Bill Penalty',\n" +
"       studentelectricbill.Electric_Bill_Total as 'Electric Bill Total',\n" +
"       studentelectricbill.billingdate as 'Electric Billing Date',\n" +
"       studentelectricbill.Due_Date as 'Electric Bill Due Date',\n" +
"       studentelectricbill.PaymentStatus as 'Electric Bill Status',\n" +
"       electricnob.transactiondate as 'Electric Bill Transaction Date',\n" +
"       studentwaterbill.WaterBill_Number as 'Water Bill Number',\n" +
"       studentwaterbill.Meter_Reading as 'Water Bill Meter Reading',\n" +
"       studentwaterbill.Subtotal as 'Water Bill Subtotal',\n" +
"       studentwaterbill.Penalty as 'Water Bill Penalty',\n" +
"       studentwaterbill.Water_Bill_Total as 'Water Bill Total',\n" +
"       studentwaterbill.billingdate as 'Water Billing Date',\n" +
"       studentwaterbill.Due_Date as 'Water Bill Due Date',\n" +
"       studentwaterbill.PaymentStatus as 'Water Bill Status',\n" +
"       waternob.transactiondate as 'Water Bill Transaction Date'\n" +
"FROM residentmanagement\n" +
"LEFT JOIN boardingfee ON residentmanagement.Student_ID = boardingfee.s_ID\n" +
"LEFT JOIN studentwaterbill ON studentwaterbill.Student_ID = residentmanagement.Student_ID\n" +
"LEFT JOIN studentelectricbill ON studentelectricbill.Student_ID = residentmanagement.Student_ID\n" +
"LEFT JOIN boardingnob ON boardingnob.studentid = residentmanagement.Student_ID\n" +
"LEFT JOIN electricnob ON residentmanagement.Student_ID = electricnob.studentid\n" +
"LEFT JOIN waternob ON residentmanagement.Student_ID = waternob.studentid  WHERE residentmanagement.Name LIKE '%" + surnamesearch.getText() + "%'";
            Rs = st.executeQuery(query);
            jTable1.setModel(DbUtils.resultSetToTableModel(Rs));

            conn.close();

        }
        catch (Exception e) {
            JOptionPane.showMessageDialog(null,"Got an exception!");
            System.err.println(e.getMessage());
        }
    }//GEN-LAST:event_surnamesearchKeyPressed

    private void surnamesearchKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_surnamesearchKeyReleased

        try{
            String url = "jdbc:mysql://localhost:3307/drs";
            Connection conn = DriverManager.getConnection(url,"root","");
            Statement st = conn.createStatement();
             String query = "SELECT residentmanagement.Student_ID as 'ID',\n" +
"       residentmanagement.Name as 'Full Name',\n" +
"       residentmanagement.Age,\n" +
"       residentmanagement.Sex,\n" +
"       residentmanagement.Birthdate,\n" +
"       residentmanagement.Civil_Status as 'Civil Status',\n" +
"       residentmanagement.Phone_Number as 'Phone Number',\n" +
"       boardingfee.d_No as 'Dorm Number',\n" +
"       boardingfee.Dorm_Type as 'Dorm Type',\n" +
"       boardingfee.Rental_Rates as 'Rental Rates',\n" +
"       boardingfee.payment_status as 'Rent Payment Status',\n" +
"       boardingnob.transactiondate as 'Rent Date of Payment',\n" +
"       studentelectricbill.ElectricBill_Number as 'Electric Bill Number',\n" +
"       studentelectricbill.Meter_Reading as 'Electric Bill Meter Reading',\n" +
"       studentelectricbill.Subtotal as 'Electric Bill Subtotal',\n" +
"       studentelectricbill.Penalty as 'Electric Bill Penalty',\n" +
"       studentelectricbill.Electric_Bill_Total as 'Electric Bill Total',\n" +
"       studentelectricbill.billingdate as 'Electric Billing Date',\n" +
"       studentelectricbill.Due_Date as 'Electric Bill Due Date',\n" +
"       studentelectricbill.PaymentStatus as 'Electric Bill Status',\n" +
"       electricnob.transactiondate as 'Electric Bill Transaction Date',\n" +
"       studentwaterbill.WaterBill_Number as 'Water Bill Number',\n" +
"       studentwaterbill.Meter_Reading as 'Water Bill Meter Reading',\n" +
"       studentwaterbill.Subtotal as 'Water Bill Subtotal',\n" +
"       studentwaterbill.Penalty as 'Water Bill Penalty',\n" +
"       studentwaterbill.Water_Bill_Total as 'Water Bill Total',\n" +
"       studentwaterbill.billingdate as 'Water Billing Date',\n" +
"       studentwaterbill.Due_Date as 'Water Bill Due Date',\n" +
"       studentwaterbill.PaymentStatus as 'Water Bill Status',\n" +
"       waternob.transactiondate as 'Water Bill Transaction Date'\n" +
"FROM residentmanagement\n" +
"LEFT JOIN boardingfee ON residentmanagement.Student_ID = boardingfee.s_ID\n" +
"LEFT JOIN studentwaterbill ON studentwaterbill.Student_ID = residentmanagement.Student_ID\n" +
"LEFT JOIN studentelectricbill ON studentelectricbill.Student_ID = residentmanagement.Student_ID\n" +
"LEFT JOIN boardingnob ON boardingnob.studentid = residentmanagement.Student_ID\n" +
"LEFT JOIN electricnob ON residentmanagement.Student_ID = electricnob.studentid\n" +
"LEFT JOIN waternob ON residentmanagement.Student_ID = waternob.studentid WHERE residentmanagement.Name LIKE '%" + surnamesearch.getText() + "%'";
            
            Rs = st.executeQuery(query);
            jTable1.setModel(DbUtils.resultSetToTableModel(Rs));

            conn.close();

        }
        catch (Exception e) {
            JOptionPane.showMessageDialog(null,"Got an exception!");
            System.err.println(e.getMessage());
        }

    }//GEN-LAST:event_surnamesearchKeyReleased

    private void surnamesearchKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_surnamesearchKeyTyped
        // TODO add your handling code here:
    }//GEN-LAST:event_surnamesearchKeyTyped

    private void dpActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_dpActionPerformed
      if(dp.isSelected()){     
           pd.setSelected(false);
                
                   try{
       
        Con= DriverManager.getConnection("jdbc:mysql://localhost:3307/drs","root","");
        St = Con.createStatement();
        Rs = St.executeQuery("SELECT residentmanagement.Student_ID as 'ID',residentmanagement.Name as 'Full Name',residentmanagement.Age,residentmanagement.Sex,residentmanagement.Birthdate,residentmanagement.Civil_Status as 'Civil Status', residentmanagement.Phone_Number as 'Phone Number',boardingfee.d_No as 'Dorm Number',boardingfee.Dorm_Type as 'Dorm Type',boardingfee.Rental_Rates as 'Rental Rates',boardingfee.payment_status as 'Rent Payment Status',boardingnob.transactiondate as 'Rent Date of Payment',studentelectricbill.ElectricBill_Number as 'Electric Bill Number',studentelectricbill.Meter_Reading as 'Electric Bill Meter Reading',studentelectricbill.Subtotal as 'Electric Bill Subtotal',studentelectricbill.Penalty as 'Electric Bill Penalty',studentelectricbill.Electric_Bill_Total as 'Electric Bill Total',studentelectricbill.billingdate as 'Electric Billing Date',studentelectricbill.Due_Date as 'Electric Bill Due Date',studentelectricbill.PaymentStatus as 'Electric Bill Status',electricnob.transactiondate as 'Electric Bill Transaction Date',studentwaterbill.WaterBill_Number as 'Water Bill Number',studentwaterbill.Meter_Reading as 'Water Bill Meter Reading',studentwaterbill.Subtotal as 'Water Bill Subtotal',studentwaterbill.Penalty as 'Water Bill Penalty',studentwaterbill.Water_Bill_Total as 'Water Bill Total',studentwaterbill.billingdate as 'Water Billing Date',studentwaterbill.Due_Date as 'Water Bill Due Date',studentwaterbill.PaymentStatus as 'Water Bill Status',waternob.transactiondate as 'Water Bill Transaction Date' \n" +
"from residentmanagement join boardingfee on residentmanagement.Student_ID=boardingfee.s_ID JOIN studentwaterbill on studentwaterbill.Student_ID=residentmanagement.Student_ID join studentelectricbill on studentelectricbill.Student_ID=residentmanagement.Student_ID join boardingnob on boardingnob.studentid=residentmanagement.Student_ID join electricnob on electricnob.studentid=residentmanagement.Student_ID join waternob ON waternob.studentid=residentmanagement.Student_ID  WHERE studentelectricbill.Penalty>0 or studentwaterbill.Penalty>0"); 
        jTable1.setModel(DbUtils.resultSetToTableModel(Rs));
        
    }catch(SQLException e){
        e.printStackTrace();
        
    }

             }else{
         
                  dormTable();

             } 
    }//GEN-LAST:event_dpActionPerformed

    private void pdActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_pdActionPerformed
      if(pd.isSelected()){     
           dp.setSelected(false);
                
                   try{
       
        Con= DriverManager.getConnection("jdbc:mysql://localhost:3307/drs","root","");
        St = Con.createStatement();
        Rs = St.executeQuery("SELECT residentmanagement.Student_ID as 'ID',residentmanagement.Name as 'Full Name',residentmanagement.Age,residentmanagement.Sex,residentmanagement.Birthdate,residentmanagement.Civil_Status as 'Civil Status', residentmanagement.Phone_Number as 'Phone Number',boardingfee.d_No as 'Dorm Number',boardingfee.Dorm_Type as 'Dorm Type',boardingfee.Rental_Rates as 'Rental Rates',boardingfee.payment_status as 'Rent Payment Status',boardingnob.transactiondate as 'Rent Date of Payment',studentelectricbill.ElectricBill_Number as 'Electric Bill Number',studentelectricbill.Meter_Reading as 'Electric Bill Meter Reading',studentelectricbill.Subtotal as 'Electric Bill Subtotal',studentelectricbill.Penalty as 'Electric Bill Penalty',studentelectricbill.Electric_Bill_Total as 'Electric Bill Total',studentelectricbill.billingdate as 'Electric Billing Date',studentelectricbill.Due_Date as 'Electric Bill Due Date',studentelectricbill.PaymentStatus as 'Electric Bill Status',electricnob.transactiondate as 'Electric Bill Transaction Date',studentwaterbill.WaterBill_Number as 'Water Bill Number',studentwaterbill.Meter_Reading as 'Water Bill Meter Reading',studentwaterbill.Subtotal as 'Water Bill Subtotal',studentwaterbill.Penalty as 'Water Bill Penalty',studentwaterbill.Water_Bill_Total as 'Water Bill Total',studentwaterbill.billingdate as 'Water Billing Date',studentwaterbill.Due_Date as 'Water Bill Due Date',studentwaterbill.PaymentStatus as 'Water Bill Status',waternob.transactiondate as 'Water Bill Transaction Date' from residentmanagement join boardingfee on residentmanagement.Student_ID=boardingfee.s_ID JOIN studentwaterbill on studentwaterbill.Student_ID=residentmanagement.Student_ID join studentelectricbill on studentelectricbill.Student_ID=residentmanagement.Student_ID join boardingnob on boardingnob.studentid=residentmanagement.Student_ID join electricnob on electricnob.studentid=residentmanagement.Student_ID join waternob ON waternob.studentid=residentmanagement.Student_ID where studentwaterbill.PaymentStatus = 'Paid' or studentelectricbill.PaymentStatus= 'Paid'"); 
        jTable1.setModel(DbUtils.resultSetToTableModel(Rs));
        
    }catch(SQLException e){
        e.printStackTrace();
        
    }

             }else{
         dormTable();

             } 
    }//GEN-LAST:event_pdActionPerformed

    private void surnamesearchActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_surnamesearchActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_surnamesearchActionPerformed


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JCheckBox dp;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable jTable1;
    private java.awt.Panel panel1;
    private java.awt.Panel panel2;
    private javax.swing.JCheckBox pd;
    private javax.swing.JTextField surnamesearch;
    // End of variables declaration//GEN-END:variables
}
